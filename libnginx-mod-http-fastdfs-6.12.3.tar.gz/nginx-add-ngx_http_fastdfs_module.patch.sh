#!/bin/bash
#BOS
#
[ -n "$(pidof nginx)" ] && echo NGINX is running, please stop it then try again. && exit 1
SCRIPT_DIR=$(dirname `realpath $0`)
pushd ${SCRIPT_DIR}
apt source nginx
select dir in $(ls); do
	echo Please select NGINX source directory.;
	if [ -d ${dir}/debian/patches ]; then
		pushd ${dir};
		break;
	fi
done

tar -Jxf ${SCRIPT_DIR}/nginx-add-ngx_http_fastdfs_module.patch.tar.xz
quilt import debian/patches/nginx-add-ngx_http_fastdfs_module.patch
quilt push debian/patches/nginx-add-ngx_http_fastdfs_module.patch
[ -x src/http/modules/fastdfs/docs/BUILD ] && . src/http/modules/fastdfs/docs/BUILD

popd
popd
#
#EOS
